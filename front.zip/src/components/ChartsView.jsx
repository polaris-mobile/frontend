import React, { useEffect, useState } from "react";
import api from "../api/axiosConfig";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { useAdmin } from "../context/AdminContext";
import PageHeader from './PageHeader';

const SignalChart = ({ data, title, lines }) => (
  <div className="bg-white p-4 rounded-lg shadow-md">
    <h3 className="text-lg font-semibold text-gray-700 mb-4">{title}</h3>
    <ResponsiveContainer width="100%" height={300}>
      <LineChart data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="time" minTickGap={30} />
        <YAxis />
        <Tooltip />
        <Legend />
        {lines.map((line) => (
          <Line
            key={line.dataKey}
            type="monotone"
            dataKey={line.dataKey}
            stroke={line.stroke}
            name={line.name}
            dot={false}
            strokeWidth={2}
          />
        ))}
      </LineChart>
    </ResponsiveContainer>
  </div>
);

const ChartsView = () => {
  const [data, setData] = useState([]);
  const { impersonatedUserId } = useAdmin();

  useEffect(() => {
    const fetchAll = async () => {
      try {
        let url = "/measurements";
        if (impersonatedUserId) {
          url += `?user_id=${impersonatedUserId}`;
        }
        const resp = await api.get(url);
        const arr = resp.data.map((r) => ({
          time: new Date(r.timestamp).toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
          }),
          rsrp: r.rsrp,
          rsrq: r.rsrq,
          rscp: r.rscp,
          ecno: r.ecno,
          rxlev: r.rxlev,
        }));
        setData(arr.reverse()); // Show oldest first
      } catch (err) {
        console.error("Error fetching for charts:", err);
      }
    };
    fetchAll();
  }, [impersonatedUserId]);

  const lteLines = [
    { dataKey: "rsrp", stroke: "#8884d8", name: "RSRP (dBm)" },
    { dataKey: "rsrq", stroke: "#82ca9d", name: "RSRQ (dB)" },
  ];

  const wcdmaLines = [
    { dataKey: "rscp", stroke: "#ffc658", name: "RSCP (dBm)" },
    { dataKey: "ecno", stroke: "#ff7300", name: "Ec/No (dB)" },
  ];

  const gsmLines = [
    { dataKey: "rxlev", stroke: "#0088FE", name: "RxLev (dBm)" },
  ];

  return (
    <div className="p-6 bg-gray-50 min-h-full">
      <PageHeader title="Dashboard" />
      <h1 className="text-3xl font-bold mb-6 text-gray-800">
        Passive Signal Metrics
      </h1>
      <div className="grid grid-cols-1 gap-6">
        <SignalChart data={data} title="4G (LTE) Metrics" lines={lteLines} />
        <SignalChart
          data={data}
          title="3G (WCDMA) Metrics"
          lines={wcdmaLines}
        />
        <SignalChart data={data} title="2G (GSM) Metrics" lines={gsmLines} />
      </div>
    </div>
  );
};

export default ChartsView;
