import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import api from '../api/axiosConfig';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { useAdmin } from '../context/AdminContext'
import PageHeader from './PageHeader';


const parameterOptions = {
  rsrp: { name: 'RSRP (4G)', unit: 'dBm', thresholds: [-100, -80], colors: ['#d7191c', '#fdae61', '#a6d96a'] },
  rsrq: { name: 'RSRQ (4G)', unit: 'dB', thresholds: [-15, -10], colors: ['#d7191c', '#fdae61', '#a6d96a'] },
  rscp: { name: 'RSCP (3G)', unit: 'dBm', thresholds: [-95, -75], colors: ['#d7191c', '#fdae61', '#a6d96a'] },
  ecno: { name: 'Ec/No (3G)', unit: 'dB', thresholds: [-12, -6], colors: ['#d7191c', '#fdae61', '#a6d96a'] },
  rxlev: { name: 'RxLev (2G)', unit: 'dBm', thresholds: [-90, -70], colors: ['#d7191c', '#fdae61', '#a6d96a'] },
  cellId: { name: 'Cell ID', unit: '' },
  tac: { name: 'TAC', unit: '' },
  lac: { name: 'LAC', unit: '' },
  plmnId: { name: 'PLMN-Id', unit: '' },
};

const MapView = () => {
  const [points, setPoints] = useState([]);
  const [selectedParam, setSelectedParam] = useState('rsrp');
  const [thresholds, setThresholds] = useState(parameterOptions.rsrp.thresholds);
  const [colors, setColors] = useState(parameterOptions.rsrp.colors);
  const [isPanelOpen, setIsPanelOpen] = useState(true);
  const { impersonatedUserId } = useAdmin();

  useEffect(() => {
    const fetchLatest = async () => {
      try {
        let url = '/measurements/latest';
        if (impersonatedUserId) {
          url += `?user_id=${impersonatedUserId}`;
      }
        const resp = await api.get(url);
        setPoints(resp.data);
      } catch (err) {
        console.error('Error fetching latest:', err);
      }
    };
    fetchLatest();
  }, [impersonatedUserId]);

  const handleParamChange = (e) => {
    const param = e.target.value;
    setSelectedParam(param);
    if (parameterOptions[param].thresholds) {
      setThresholds(parameterOptions[param].thresholds);
      setColors(parameterOptions[param].colors);
    }
  };

  const handleThresholdChange = (index, value) => {
    const newThresholds = [...thresholds];
    newThresholds[index] = Number(value);
    setThresholds(newThresholds);
  };

  const handleColorChange = (index, value) => {
    const newColors = [...colors];
    newColors[index] = value;
    setColors(newColors);
  };

  const addThreshold = () => {
    setThresholds([...thresholds, 0]);
    setColors([...colors, '#cccccc']);
  };

  const removeThreshold = (index) => {
    setThresholds(thresholds.filter((_, i) => i !== index));
    setColors(colors.filter((_, i) => i !== index));
  };

  const getColor = (value) => {
    if (value === null || value === undefined || !parameterOptions[selectedParam].thresholds) {
      return '#808080'; // Default grey for no data or categorical data
    }
    const sortedThresholds = [...thresholds].sort((a, b) => a - b);
    const sortedColors = [...colors];
    
    for (let i = 0; i < sortedThresholds.length; i++) {
      if (value < sortedThresholds[i]) {
        return sortedColors[i];
      }
    }
    return sortedColors[sortedColors.length - 1];
  };

  const center = points.length > 0 && points[0].latitude && points[0].longitude
    ? [points[0].latitude, points[0].longitude]
    : [35.6892, 51.3890]; // Default to Tehran

  return (
    // ★ FIX: Ensure the container takes up the full height of the main layout area ★
    <div className="relative h-full w-full">
      <PageHeader title="Map View" />
      <MapContainer center={center} zoom={13} style={{ height: '100%', width: '100%' }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {points.map((p) => {
          if (p.latitude === null || p.longitude === null) return null;
          const value = p[selectedParam];
          return (
            <CircleMarker
              key={p.id}
              center={[p.latitude, p.longitude]}
              radius={6}
              pathOptions={{ color: getColor(value), fillColor: getColor(value), fillOpacity: 0.7 }}
            >
              <Popup>
                <div className="text-sm">
                  <strong>Time:</strong> {new Date(p.timestamp).toLocaleString()}<br />
                  <strong>Tech:</strong> {p.networkType || 'N/A'}<br />
                  <strong>{parameterOptions[selectedParam].name}:</strong> {value ?? 'N/A'} {parameterOptions[selectedParam].unit}
                </div>
              </Popup>
            </CircleMarker>
          );
        })}
      </MapContainer>

      <div className="absolute top-4 right-4 z-[1000] bg-white p-4 rounded-lg shadow-lg w-80">
        <button onClick={() => setIsPanelOpen(!isPanelOpen)} className="w-full flex justify-between items-center font-bold text-lg mb-2">
          <span>Map Controls</span>
          {isPanelOpen ? <ChevronUp /> : <ChevronDown />}
        </button>
        {isPanelOpen && (
          <>
            <div className="mt-4">
              <label className="block font-semibold mb-1">Parameter</label>
              <select value={selectedParam} onChange={handleParamChange} className="w-full p-2 border rounded">
                {Object.entries(parameterOptions).map(([key, { name }]) => (
                  <option key={key} value={key}>{name}</option>
                ))}
              </select>
            </div>
            {parameterOptions[selectedParam].thresholds && (
              <div className="mt-4">
                <label className="block font-semibold mb-1">Thresholds & Colors</label>
                {thresholds.map((thresh, i) => (
                  <div key={i} className="flex items-center space-x-2 mb-2">
                    <span>Value &lt;</span>
                    <input type="number" value={thresh} onChange={(e) => handleThresholdChange(i, e.target.value)} className="w-20 p-1 border rounded" />
                    <input type="color" value={colors[i]} onChange={(e) => handleColorChange(i, e.target.value)} className="w-8 h-8" />
                    <button onClick={() => removeThreshold(i)} className="text-red-500">&times;</button>
                  </div>
                ))}
                <div className="flex items-center space-x-2">
                    <span>Else</span>
                    <input type="color" value={colors[colors.length-1]} onChange={(e) => handleColorChange(colors.length-1, e.target.value)} className="w-8 h-8" />
                </div>
                <button onClick={addThreshold} className="mt-2 text-blue-500 text-sm">+ Add Threshold</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default MapView;
