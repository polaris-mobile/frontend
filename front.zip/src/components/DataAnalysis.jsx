import React, { useEffect, useState, useMemo } from "react";
import api from "../api/axiosConfig";
import {
  BarChart,
  Bar,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { useAdmin } from "../context/AdminContext";
import PageHeader from "./PageHeader";

const StatCard = ({ title, value, unit }) => (
  <div className="bg-white p-6 rounded-lg shadow-md">
    <h3 className="text-gray-500 text-sm font-bold uppercase">{title}</h3>
    <p className="text-3xl font-bold text-gray-800 mt-2">
      {value} <span className="text-lg font-medium text-gray-600">{unit}</span>
    </p>
  </div>
);

const COLORS = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#AF19FF"];

const DataAnalysis = () => {
  const [measurements, setMeasurements] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const { impersonatedUserId } = useAdmin();

  useEffect(() => {
    setIsLoading(true);
    let url = "/measurements";
    if (impersonatedUserId) {
      url += `?user_id=${impersonatedUserId}`;
    }
    api
      .get(url)
      .then((response) => {
        setMeasurements(response.data);
        setIsLoading(false);
      })
      .catch((error) => {
        console.error("Failed to fetch measurements for analysis:", error);
        setIsLoading(false);
      });
  }, [impersonatedUserId]);

  const stats = useMemo(() => {
    if (measurements.length === 0) return null;

    const rsrpValues = measurements
      .map((d) => d.rsrp)
      .filter((v) => v !== null);
    const avgRsrp = rsrpValues.reduce((a, b) => a + b, 0) / rsrpValues.length;
    const networkTypes = [...new Set(measurements.map((d) => d.networkType))];

    return {
      total: measurements.length,
      avgRsrp: rsrpValues.length > 0 ? avgRsrp.toFixed(2) : "N/A",
      uniqueNetworks: networkTypes.join(", "),
      latestTimestamp: new Date(measurements[0].timestamp).toLocaleString(),
    };
  }, [measurements]);

  const networkTypeDistribution = useMemo(() => {
    const counts = {};
    measurements.forEach((m) => {
      const tech = m.networkType || "Unknown";
      counts[tech] = (counts[tech] || 0) + 1;
    });
    return Object.keys(counts).map((key) => ({
      name: key,
      value: counts[key],
    }));
  }, [measurements]);

  const rsrpDistribution = useMemo(() => {
    const buckets = {
      "Excellent (> -85)": 0,
      "Good (-85 to -95)": 0,
      "Fair (-95 to -105)": 0,
      "Poor (-105 to -115)": 0,
      "Bad (< -115)": 0,
    };
    measurements.forEach((m) => {
      if (m.rsrp) {
        if (m.rsrp > -85) buckets["Excellent (> -85)"]++;
        else if (m.rsrp > -95) buckets["Good (-85 to -95)"]++;
        else if (m.rsrp > -105) buckets["Fair (-95 to -105)"]++;
        else if (m.rsrp > -115) buckets["Poor (-105 to -115)"]++;
        else buckets["Bad (< -115)"]++;
      }
    });
    return Object.keys(buckets).map((key) => ({
      name: key,
      count: buckets[key],
    }));
  }, [measurements]);

  // useEffect(() => {
  //   api
  //     .get("/measurements")
  //     .then((response) => {
  //       const data = response.data;
  //       if (data.length > 0) {
  //         const totalMeasurements = data.length;
  //         const rsrpValues = data.map((d) => d.rsrp).filter((v) => v !== null);
  //         const avgRsrp =
  //           rsrpValues.reduce((a, b) => a + b, 0) / rsrpValues.length;
  //         const networkTypes = [...new Set(data.map((d) => d.networkType))];

  //         setStats({
  //           total: totalMeasurements,
  //           avgRsrp: avgRsrp.toFixed(2),
  //           uniqueNetworks: networkTypes.join(", "),
  //           latestTimestamp: new Date(data[0].timestamp).toLocaleString(),
  //         });
  //       }
  //       setIsLoading(false);
  //     })
  //     .catch((error) => console.error("Error fetching analysis data:", error));
  // }, []);

  const rsrpVsRsrqData = useMemo(() => {
    return measurements
      .filter((m) => m.rsrp != null && m.rsrq != null)
      .map((m) => ({ x: m.rsrp, y: m.rsrq }));
  }, [measurements]);
  if (isLoading) {
    return <div className="p-6">Analyzing data...</div>;
  }
  return (
    <div className="bg-gray-50 min-h-full">
      <PageHeader title="Advanced Data Analysis" />
      <div className="p-6">
        {stats ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
            <StatCard title="Total Measurements" value={stats.total} />
            <StatCard title="Average RSRP" value={stats.avgRsrp} unit="dBm" />
            <StatCard title="Network Types" value={stats.uniqueNetworks} />
            <StatCard title="Latest Reading" value={stats.latestTimestamp} />
          </div>
        ) : (
          <p>No data available to analyze.</p>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Pie Chart for Network Type Distribution */}
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700 mb-4">
              Network Technology Distribution
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <PieChart>
                <Pie
                  data={networkTypeDistribution}
                  dataKey="value"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  outerRadius={150}
                  fill="#8884d8"
                  label
                >
                  {networkTypeDistribution.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* RSRP vs RSRQ Scatter Plot */}
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="text-lg font-semibold text-gray-700 mb-4">
              RSRP vs. RSRQ Correlation
            </h3>
            <ResponsiveContainer width="100%" height={400}>
              <ScatterChart>
                <CartesianGrid />
                <XAxis
                  type="number"
                  dataKey="x"
                  name="RSRP (dBm)"
                  unit="dBm"
                  domain={[-130, -70]}
                />
                <YAxis
                  type="number"
                  dataKey="y"
                  name="RSRQ (dB)"
                  unit="dB"
                  domain={[-20, -3]}
                />
                <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                <Legend />
                <Scatter
                  name="Measurements"
                  data={rsrpVsRsrqData}
                  fill="#82ca9d"
                  shape="circle"
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DataAnalysis;
