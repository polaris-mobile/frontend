import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Map, List, BarChart2, Settings, Download, Upload } from 'lucide-react';
import api from '../api/axiosConfig';
import AdminUserSelector from './AdminUserSelector';
import PageHeader from './PageHeader';
import { useAdmin } from '../context/AdminContext';

const API_BASE_URL = api.defaults.baseURL;

const Dashboard = () => {
  const username = localStorage.getItem('username');
  const [selectedUserId, setSelectedUserId] = useState(null);
  const role = localStorage.getItem('role');
  const { impersonatedUserId } = useAdmin(); // Get the selected user ID
  
  // Update the base URL for direct links
  const csvUrl = `${API_BASE_URL}/export/csv${impersonatedUserId ? `?user_id=${impersonatedUserId}` : ''}`;
  const kmlUrl = `${API_BASE_URL}/export/kml${impersonatedUserId ? `?user_id=${impersonatedUserId}` : ''}`;

  useEffect(() => {
    let url = '/measurements';
    if (selectedUserId) {
        url = `/measurements?user_id=${selectedUserId}`;
    }
    // api.get(url).then(...)
}, [selectedUserId]);

  const dashboardItems = [
    { to: '/map', icon: Map, label: 'Live Map View' },
    { to: '/table', icon: List, label: 'Browse All Data' },
    { to: '/active-tests', icon: BarChart2, label: 'Active Test Charts' },
    { to: '/settings', icon: Settings, label: 'Client Configuration' },
    { href: csvUrl, icon: Download, label: 'Export as CSV' },
    { href: kmlUrl, icon: Upload, label: 'Export as KML' },
  ];

  const renderItem = (item) => {
    const content = (
      <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow flex flex-col items-center justify-center h-40">
        <item.icon className="w-12 h-12 mb-4 text-blue-600" />
        <span className="text-lg font-semibold text-gray-700">{item.label}</span>
      </div>
    );

    return item.to ? (
      <Link to={item.to} key={item.label}>{content}</Link>
    ) : (
      <a href={item.href} key={item.label} download>{content}</a>
    );
  };

  return (
    <div>
      <AdminUserSelector selectedUserId={selectedUserId} setSelectedUserId={setSelectedUserId} />
      <PageHeader title="Dashboard" />
      <div className="p-6 bg-gray-50 min-h-full">
        <h1 className="text-3xl font-bold mb-2 text-gray-800">Welcome, {username}!</h1>
        <p className="text-md text-gray-600 mb-8">Select a tool below to analyze the collected network data.</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dashboardItems.map(renderItem)}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
